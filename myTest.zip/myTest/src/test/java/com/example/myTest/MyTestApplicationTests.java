package com.example.myTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
